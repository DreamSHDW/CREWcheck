// Simple starter script
console.log("Welcome to CrewCheck!");
